def main():
    name_and_lastname = input("please enter your first and last names: ")
    age = input("please enter your age: ")
    city = input("please enter your city: ")

    print(f" * Hello {name_and_lastname}, \n * Age: {age} \n * City: {city}")


if __name__ == "__main__":
    main()
